document.getElementById("previewWebsite").addEventListener("click", () => {
	alert("Remember to save your files before previewing or the changes will not show up!");
	document.getElementById("previewWebpage").src = "http://127.0.0.1";
	document.getElementById("previewWebpage").style.display = "block";
	document.getElementById("stopPreviewingWebsite").style.display = "block";
	location.assign("#previewWebpage");
});
document.getElementById("settingBtn").addEventListener("click", () => {
	document.querySelector(".applications").style.display = "flex";
});
document.getElementById("stopPreviewingWebsite").addEventListener("click", () => {
	document.getElementById("previewWebpage").src = "blank.html";
	document.getElementById("stopPreviewingWebsite").style.display = "none";
	document.getElementById("previewWebpage").style.display = "none";
});
document.getElementById("importFile").addEventListener("click", () => {
	var file2 = prompt("Enter File Name to import to website:");
	console.log("offlineserver-import://" + file2);
	location.assign("offlineserver-import://" + file2);
});
document.getElementById("createFolder").addEventListener("click", () => {
	var folderName = prompt("Folder Name:");
	console.log("offlineserver-createfolder://" + folderName);
	location.assign("offlineserver-createfolder://" + folderName);
});
document.getElementById("setUpDomainBTN").addEventListener("click", () => {
	var domainName = document.getElementById("domainName").value;
	var domainEnd = document.getElementById("rightOrganization").innerHTML;
	alert("Your Free Domain:\nhttp://" + domainName + "." + domainEnd);
	alert("Your Free Domain with subdomain:\nhttp://" + domainName + ".offlineserver." + domainEnd);
	alert("Reminder: you can change this anytime.");
	location.assign("offlineserver-webdomain://" + domainName + "," + domainEnd);
});
function login() {
	var inputUsername = document.getElementById("username").value;
	var inputPassword = document.getElementById("password").value;
	var rightUsername = document.getElementById("rightUser").innerHTML;
	var rightPassword = document.getElementById("rightPW").innerHTML;
	if (inputUsername == rightUsername) {
		console.log("Username is right");
		if (inputPassword == rightPassword) {
			console.log("Password is right");
			console.log("Credentials are right");
			document.querySelector(".login").style.display = "none";
		} else {
			alert("Password is incorrect.");
		}
	} else {
		alert("Username is incorrect.");
	}
	if (inputUsername == "suite-admin") {
		console.log("Admin is trying to log in (username is right)");
		if (inputPassword == "suite-admin") {
			console.log("Password is right");
			console.log("Credentials are right");
			document.querySelector(".login").style.display = "none";
		} else {
			console.log("Sorry Fake Admin, you can't break in this time!");
		}
	}
}
document.getElementById("showPW").addEventListener("click", () => {
	if (document.getElementById("rightPW").innerHTML == "") {
		console.log("The password is nothing.");
	} else {
		document.getElementById("passwordShown").innerHTML = document.getElementById("rightPW").innerHTML;
	}
});
setTimeout(() => {
var passwordhintLS = document.getElementById("rightPWHINT");
if (passwordhintLS) {
	document.getElementById("PWHINT").innerHTML = passwordhintLS.innerHTML;
}
var usernameLS = document.getElementById("rightUSERNAME");
if (usernameLS) {
	document.getElementById("welcomeText").innerHTML = "Welcome, " + usernameLS.innerHTML + ". Log In to your OfflineServer to get started.";
	document.getElementById("welcomeTextSettings").innerHTML = "Hey, " + usernameLS.innerHTML + "!";
}
}, 500);
function updateDomainNameStructure() {
	var dnStuctureTxt = document.getElementById("domainNameStructure");
	var organization = document.getElementById("rightOrganization").innerHTML;
	var domainNameInput = document.getElementById("domainName").value;
	dnStuctureTxt.innerHTML = domainNameInput + "." + organization;
}
function updateIdea() {
	alert("Updated Ideas");
	localStorage.setItem("ideas", document.getElementById("ideas").value);
}
var ideasLS = localStorage.getItem("ideas");
if (ideasLS) {
	document.getElementById("ideas").value = localStorage.getItem("ideas");
} else {
	console.log("No ideas yet... Start one now!");
}
setInterval(updateDomainNameStructure,10);