document.getElementById("openFile").addEventListener("click", () => {
	var file = prompt("File Location (In your computer, need file path please):");
	location.assign("offlineserver-openfile://" + file);
});
document.getElementById("previewWebsite").addEventListener("click", () => {
	alert("Remember to save your files before previewing or the changes will not show up!");
	document.getElementById("previewWebpage").src = "http://127.0.0.1";
	document.getElementById("previewWebpage").style.display = "block";
	document.getElementById("stopPreviewingWebsite").style.display = "block";
	location.assign("#previewWebpage");
});
document.getElementById("stopPreviewingWebsite").addEventListener("click", () => {
	document.getElementById("previewWebpage").src = "blank.html";
	document.getElementById("stopPreviewingWebsite").style.display = "none";
	document.getElementById("previewWebpage").style.display = "none";
});
document.getElementById("importFile").addEventListener("click", () => {
	var file2 = prompt("Enter File Name to import to website:");
	console.log("offlineserver-import://" + file2);
	location.assign("offlineserver-import://" + file2);
});
document.getElementById("createFolder").addEventListener("click", () => {
	var folderName = prompt("Folder Name:");
	console.log("offlineserver-createfolder://" + folderName);
	location.assign("offlineserver-createfolder://" + folderName);
});
document.getElementById("domain").addEventListener("click", () => {
	var domainName = prompt("Set your domain name");
	var domainEnd = prompt("Set your domain ending e.g: .com, .org, .net, .gov. DO NOT ADD THE PERIOD!!");
	alert("Your Free Domain:\nhttp://" + domainName + "." + domainEnd);
	alert("Your Free Domain with subdomain:\nhttp://" + domainName + ".offlineserver." + domainEnd);
	alert("Reminder: you can change this anytime.");
	location.assign("offlineserver-webdomain://" + domainName + "," + domainEnd);
});